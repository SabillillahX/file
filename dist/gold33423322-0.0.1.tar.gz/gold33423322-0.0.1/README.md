# Golden Ratio 

> **WORK ON PROGRESS**

## Installation
```shell
pip install gold33423322
```

## Usage
Basic Usage:
```python
from gold33423322 import GoldenRatio

objects = Anime()

objects.tampilkan hasil()
